package value;

public class NatValue extends ExpValue<Integer> {

    public NatValue(Integer value) {
        super(value);
    }
}
