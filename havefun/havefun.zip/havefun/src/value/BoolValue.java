package value;

public class BoolValue extends ExpValue<Boolean> {

    public BoolValue(Boolean value) {
        super(value);
    }
}
